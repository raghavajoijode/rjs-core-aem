/* jshint undef: true, unused: true, esversion:5, node: true */
/* globals window, $ */

(function () {
  // register an RTE validator to make RTE required
  window.customValidator.registerRteValidator({
    selector: '[data-rte-required]',
    validate: function (element) {
      // if there is a value, return
      if ($(element).val()) return;
      // no value, return error message
      else return 'This field is required.';
    }
  });
})();